package constants;

public class ConstantPaths {

    public final static String LOCATOR_PATH ="src\\main\\resources\\ConfigFiles\\";
    public final static String CONFIG_PATH ="src\\main\\resources\\ConfigFiles\\Config.properties";
}
