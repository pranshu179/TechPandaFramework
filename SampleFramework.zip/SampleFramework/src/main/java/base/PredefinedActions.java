package base;

import com.beust.ah.A;
import org.apache.log4j.Logger;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.edge.EdgeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxOptions;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import java.time.Duration;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;

public class PredefinedActions {

    private static WebDriver driver;
    private static WebDriverWait wait;

    private static Logger log = Logger.getLogger(PredefinedActions.class);


    public static void initializeBrowser(String url, String browserName, boolean isHeadless) {
        switch (browserName.toUpperCase()) {
            case "CHROME":
                ChromeOptions chromeOptions = new ChromeOptions();
                if (isHeadless) {
                    chromeOptions.setHeadless(true);
                }
                chromeOptions.addArguments("--remote-allow-origins=*");
                driver = new ChromeDriver(chromeOptions);
                break;
            case "FIREFOX":
                FirefoxOptions firefoxOptions = new FirefoxOptions();
                if (isHeadless) {
                    firefoxOptions.setHeadless(true);
                }
                driver = new FirefoxDriver(firefoxOptions);
                break;
            case "EDGE":
                EdgeOptions edgeOptions = new EdgeOptions();
                if (isHeadless){
                    edgeOptions.addArguments("--headess=new");
                }
                driver = new EdgeDriver(edgeOptions);
                break;
            default:
                System.out.println("Invalid Browser");
                break;
        }
        log.trace("User has opened " + browserName + " browser");
        driver.manage().window().maximize();
        driver.get(url);
        log.trace(" User able to open the :"+ url);
        wait = new WebDriverWait(driver, Duration.ofSeconds(10));
    }

    protected WebElement getElement(String locator, boolean isWaitRequired) {

        String locatorType = getLocatorType(locator);
        String locatorValue = getLocatorValue(locator);

        WebElement element = null;
        if (isWaitRequired == true) {
            element = wait.until(ExpectedConditions.visibilityOfElementLocated(getByReference(locatorType, locatorValue)));
        }
        log.trace("User is trying to get element.");
    return element;
    }

    private String getLocatorType(String locator) {
       String locatorType= null;
        try {
            locatorType = locator.split("]:-")[0].substring(1);
        } catch (IndexOutOfBoundsException indexOutOfBoundsException){
            log.warn("Check locator Type, Something is missing.");
        }
        return locatorType;

    }

    private String getLocatorValue(String locator) {
      String locatorValue= null;
      try {
           locatorValue = locator.split("]:-")[1];
      }catch (IndexOutOfBoundsException indexOutOfBoundsException){
          log.warn("Check Locator value, Something is missing.");
        }
        return locatorValue;
    }

    private By getByReference(String locatorType, String locatorValue) {

        switch (locatorType.toUpperCase()) {
            case "XPATH":
                return By.xpath(locatorValue);
            case "ID":
                return By.id(locatorValue);
            case "CLASSNAME":
                return By.className(locatorValue);
            case "PARTIALLINK":
                return By.partialLinkText(locatorValue);
            case "LINKTEXT":
                return By.linkText(locatorValue);
            case "CSS":
                return By.cssSelector(locatorValue);
            case "TAGNAME":
                return By.tagName(locatorValue);
            case "NAME":
                return By.name(locatorValue);
            default:
                log.trace("Invalid Locator Type");
        }
        return null;
    }

    protected WebElement clickOnElement(String locator, boolean isWaitRequired) {
        WebElement element = getElement(locator, isWaitRequired);
        if (isWaitRequired) {
            wait.until(ExpectedConditions.elementToBeClickable(element)).click();
        } else {
            element.click();
        }
        log.trace("User is trying to click on element.");
        return element;
    }

    protected String getElementText(String locator, boolean isWaitRequired) {
        log.trace("User is trying to get element text.");
        return getElement(locator, isWaitRequired).getText();

    }

    protected String getPageTitle() {
        log.trace("User is trying to get page title.");
        return driver.getTitle();
    }

    protected void selectDropDownByValue(String locator, boolean isWaitRequired, String selectValue) {
        WebElement element = getElement(locator, isWaitRequired);
        Select select = new Select(element);
        select.selectByValue(selectValue);

    }

    protected List<WebElement> getWebElementList(String locator, boolean isWaitRequired) {
        String locatorType = getLocatorType(locator);
        String locatorValue = getLocatorValue(locator);
        List<WebElement> elementList = driver.findElements(getByReference(locatorType, locatorValue));
        log.trace("User is trying to get web element list.");
        return elementList;

    }

    protected List<String> getElementListInString(String locator, boolean isWaitRequired) {
        List<WebElement> tempList = getWebElementList(locator, isWaitRequired);
        List<String> elementListInString = new ArrayList<>();
        for (WebElement element : tempList) {
            elementListInString.add(element.getText());
        }
        log.trace("User is trying to get web element list in String.");
        return elementListInString;
    }

    protected void hoverOnElement(WebElement element) {
/*
        WebElement element = getElement(locator,isWaitRequired);
*/
        Actions action = new Actions(driver);
        action.moveToElement(element).perform();
        action.moveToElement(element).
                contextClick().
                click().perform();
        log.trace("User is trying to hover and click on the element.");

    }

    protected Set<String> getWindowHandles() {
        Set<String> setWindow = driver.getWindowHandles();
        log.trace("User is trying to get window Handles.");
        return setWindow;
    }

    protected String getWindowHandle() {
        return driver.getWindowHandle();
    }

    protected void switchToWindow(String window) {
        driver.switchTo().window(window);
    }
     protected void enterText(WebElement element, String textToBe){
        if(element.isDisplayed()){
            element.sendKeys(textToBe);
        }
        else{
            element.sendKeys(textToBe);
        }
     }
     protected void acceptAlert(){
        wait.until(ExpectedConditions.alertIsPresent());
         Alert alert = driver.switchTo().alert();
         alert.accept();
     }
     protected void dismissAlert(){
        wait.until(ExpectedConditions.alertIsPresent());
        Alert alert = driver.switchTo().alert();
        alert.dismiss();
     }
     protected void clickThenEnterText(WebElement element, String textToBe){
        if(element.isDisplayed()){
        Actions actions = new Actions(driver);
        actions.click(element).sendKeys(element,textToBe).perform();
            log.trace("User is trying to get click and then entering the information.");

        }
     }
    protected void closeDriver(){
        driver.close();
        log.trace("User is trying to closing the driver.");
    }

}
