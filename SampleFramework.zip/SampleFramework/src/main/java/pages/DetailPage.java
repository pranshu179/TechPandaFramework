package pages;

import base.PredefinedActions;
import constants.ConstantPaths;
import org.apache.xmlbeans.impl.soap.DetailEntry;
import utils.PropertyReading;

import java.util.logging.Logger;

public class DetailPage extends PredefinedActions {

 private static DetailPage detailpage;

 private static PropertyReading detailpageprop;
 private static Logger log = Logger.getLogger("PropertyReading");

 private DetailPage(){
     detailpageprop = new PropertyReading(ConstantPaths.LOCATOR_PATH+"DetailPage.properties");
 }

 public static DetailPage getDetailPage(){
     if (detailpage == null)
         detailpage= new DetailPage();
     return detailpage;
 }
  public double getDetailPagePrice() {
      return Double.parseDouble(getElementText(detailpageprop.getValue("productPrice"), true).replace("$", ""));
 }




}
