package pages;

import base.PredefinedActions;
import constants.ConstantPaths;
import utils.PropertyReading;

import java.util.*;
import java.util.logging.Logger;

public class ProductPage extends PredefinedActions {

    private static ProductPage productPage;
    private static PropertyReading productPageProp;
    private String parentWindow;
    private static Logger log = Logger.getLogger("ProductPage");


    private ProductPage() {
        productPageProp = new PropertyReading(ConstantPaths.LOCATOR_PATH + "ProductPage.properties");
    }

    public static ProductPage getProductPage() {
        if (productPage == null)
            productPage = new ProductPage();
        return productPage;
    }

    public boolean isHeadingVisible() {
        log.info("Heading is Visible.");
        return getElementText(productPageProp.getValue("productPageHeading"), true).contains("MOBILE");
    }

    public List<String> nameListBeforeSorting() {
        log.info("User is Fetching list Before Sorting.");
        return getElementListInString(productPageProp.getValue("productNames"), true);
    }

    public void sortByName() {
        log.info("List is sorted By Name.");
        selectDropDownByValue(productPageProp.getValue("selectElement"), true,
                productPageProp.getValue("selectValue"));
    }

    public List<String> sortedByNameList() {
        List<String> tempList = nameListBeforeSorting();
        Collections.sort(tempList);
        List<String> tempListAfterSort = tempList;
        log.info("List Sorted By NameList.");
        return tempListAfterSort;
    }

    public double getMobilePrice() {
        log.info("User is Getting Mobile Price in Console.");
        return Double.parseDouble(getElementText(productPageProp.getValue("mobileProduct"), true).replace("$", ""));
    }

    public void goToProductDetailPage(String productName) {
        String product = productPageProp.getValue("productMobile");
        product = String.format(product, productName);
        clickOnElement(product, true);
    }

    public void addToCartProduct(String productName) {
        productName = String.format(productPageProp.getValue("addToCartBtn"), productName);
        clickOnElement(productName, true);
    }

    public void clickOnAddToCompareBtn(String productName) {
        productName = String.format(productPageProp.getValue("addToCompare1"), productName);
        clickOnElement(productName, true);
    }

    public void clickOnProductCompare() {
        clickOnElement(productPageProp.getValue("compareBtn"), true);
        Set<String> windowHandles = getWindowHandles();
        Iterator<String> itr = windowHandles.iterator();
        parentWindow = itr.next();
        String childWindow = itr.next();
        switchToWindow(childWindow);
    }

    public ArrayList<String> getProductNameText() {
        ArrayList<String> tempList = new ArrayList<>();
        String firstProductText = getElementText(productPageProp.getValue("productXperia"), true);
        String secondProductText = getElementText(productPageProp.getValue("productIPhone"), true);
        tempList.add(firstProductText);
        tempList.add(secondProductText);
        return tempList;
    }

    public boolean isComparePageVisible(){
        return getElementText(productPageProp.getValue("compareHeading"),true).contains("COMPARE PRODUCTS");
    }

    public ArrayList <String> getComparePageProductName(){
        ArrayList<String> tempList = new ArrayList<>();
        tempList.add(getElementText(productPageProp.getValue("comparePageXperia"), true));
        tempList.add(getElementText(productPageProp.getValue("comparePageIPhone"), true));
        return tempList;
    }


    public void afterAction() {
        closeDriver();
        switchToWindow(parentWindow);
    }


}
