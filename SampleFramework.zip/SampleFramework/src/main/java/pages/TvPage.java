package pages;

import base.PredefinedActions;
import constants.ConstantPaths;
import utils.PropertyReading;

public class TvPage extends PredefinedActions {
    private static TvPage tvpage;

    private static PropertyReading tvpageprop;

    private TvPage() {
        tvpageprop = new PropertyReading(ConstantPaths.LOCATOR_PATH + "tvPage.properties");

    }

    public static TvPage getTvPage() {
        if (tvpage == null)
            tvpage = new TvPage();
        return tvpage;
    }

    public void goToTvPage(){
        clickOnElement(tvpageprop.getValue("goToTvPage"),true);
    }

    public void addProductToWishlist(String productName){
        productName = String.format(tvpageprop.getValue("addToWishlist"), productName);
        clickOnElement(productName,true);
    }

    public void clickOnShareWishlist(){
        clickOnElement(tvpageprop.getValue("shareWishlist"),true);
    }


}
