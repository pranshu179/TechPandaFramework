package pages;

import base.PredefinedActions;
import constants.ConstantPaths;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;
import utils.PropertyReading;

public class ShoppingCartPage extends PredefinedActions {

    private static ShoppingCartPage shoppingCartPage;
    private static PropertyReading shoppingCartProp;


    private ShoppingCartPage() {
        shoppingCartProp = new PropertyReading(ConstantPaths.LOCATOR_PATH + "ShopingCart.properties");
    }

    public static ShoppingCartPage getShoppingCartPage() {
        if (shoppingCartPage == null) {
            shoppingCartPage = new ShoppingCartPage();
        }
        System.out.println("Shopping Cart Page Launch Successfully.");
        return shoppingCartPage;
    }

    public void addProductToQty(String quantity) {
        WebElement element = getElement(shoppingCartProp.getValue("qtyValue"), true);
        element.clear();
        element.sendKeys(quantity);
        System.out.println("Product Quantity added.");
    }

    public void updateQtyButton() {
        getElement(shoppingCartProp.getValue("updateBtn"), true).click();
        System.out.println("Product Quantity Update Successfully.");
    }

    public String getErrorMessage() {
        return getElementText(shoppingCartProp.getValue("errorMessage"), true);
    }

    public boolean isErrorMessageVisible() {
        return getElementText(shoppingCartProp.getValue("errorMessage"), true).contains("Some of the products cannot be ordered in requested quantity.");
    }

    public void emptyCart() {
        getElement(shoppingCartProp.getValue("emptyCart"), true).click();
        System.out.println("Cart is Empty.");
    }

    public boolean verifyEmptyCart() {
        return getElementText(shoppingCartProp.getValue("emptyCartMessage"), true).contains("SHOPPING CART IS EMPTY");
    }


    public void proceedToCheckout() {
        clickOnElement(shoppingCartProp.getValue("proceedToCheckout"), true);
    }

    /**
     * public Map<String, String> getShopingDetails() {
     * HashMap<String, String> tempList = new HashMap<>();
     * tempList.put("address", shopingdetails.getValue("address"));
     * tempList.put("city", shopingdetails.getValue("city"));
     * tempList.put("zip", shopingdetails.getValue("zip"));
     * tempList.put("country",shopingdetails.getValue("country"));
     * tempList.put("telephone",shopingdetails.getValue("telephone"));
     * return tempList;
     * }
     * public void fillShopingInformation(String address, String city, String zip){
     * clickThenEnterText(getElement(shopingcartprop.getValue("inputAddress"),true), address);
     * clickThenEnterText(getElement(shopingcartprop.getValue("inputCity"), true),city);
     * clickThenEnterText(getElement(shopingcartprop.getValue("inputState"),true),zip);
     * //       clickThenEnterText(getElement(shopingcartprop.getValue(""), true),country);
     * //       clickThenEnterText(getElement(shopingcartprop.getValue(""),true),telephone);
     */
    public void fillShoppingForm(String address, String city, String state, String zip, String country, String telephone) {
        clickOnElement(shoppingCartProp.getValue("inputAddress"), true).sendKeys(address);
        clickOnElement(shoppingCartProp.getValue("inputCity"), true).sendKeys(city);
        WebElement element1 = getElement(shoppingCartProp.getValue("inputState"), true);
        Select selectState = new Select(element1);
        selectState.selectByVisibleText(state);
        clickOnElement(shoppingCartProp.getValue("inputZip"), true).sendKeys(zip);
        WebElement element2 = getElement(shoppingCartProp.getValue("inputCountry"), true);
        Select selectCountry = new Select(element2);
        selectCountry.selectByVisibleText(country);
        clickOnElement(shoppingCartProp.getValue("inputTelephone"), true).sendKeys(telephone);
    }

    public void selectCountryStateAndZip(String country, String state, String zip) {
        WebElement element1 = getElement(shoppingCartProp.getValue("inputCountryInShoppingCartPage"), true);
        Select selectCountry = new Select(element1);
        selectCountry.selectByVisibleText(country);
        System.out.println("Country selected.");
        WebElement element2 = getElement(shoppingCartProp.getValue("inputStateInShoppingCartPage"), true);
        Select selectState = new Select(element2);
        selectState.selectByVisibleText(state);
        System.out.println("State selected.");
        clickOnElement(shoppingCartProp.getValue("inputZipInShoppingCartPage"), true).sendKeys(zip);
        System.out.println("Zip Code Filled Successfully.");
    }

    public void clickOnEstimateButton() {
        System.out.println("Click On Estimate Button.");
        clickOnElement(shoppingCartProp.getValue("estimateButton"), true);
    }

    public void clickOnFixedRate() {
        System.out.println("Click On FIXED RATE Successfully.");
        clickOnElement(shoppingCartProp.getValue("fixedRate"), true);
        clickOnElement(shoppingCartProp.getValue("updateButton"), true);
    }

    public double getFlatRatePrice() {
        double price1 = Double.parseDouble(getElementText(shoppingCartProp.getValue("updateFixedPrice"), true).replace("$", "").replace(",", ""));
        System.out.println("The Flat Price is :" + price1 + ".");
        return price1;
    }

    public double getSubTotalPrice() {
        double price2 = Double.parseDouble(getElementText(shoppingCartProp.getValue("subTotalPrice"), true).replace("$", "").replace(",", ""));
        System.out.println("The SubTotal Price is :" + price2 + ".");
        return price2;
    }

    public double getGrandTotalPrice() {
        double price3 = Double.parseDouble(getElementText(shoppingCartProp.getValue("shoppingCartPagePrice"), true).replace("$", "").replace(",", ""));
        System.out.println("The Grand Price is:" + price3 + ".");
        return price3;
    }

    public boolean isTotalPriceCorrect() {
        if (getFlatRatePrice() + getSubTotalPrice() == getGrandTotalPrice()) {
            System.out.println("The is Matched.");
        }
        return true;
    }

    public void clickOnProceedToCheckOut() {
        System.out.println("Proceed To Checkout Click Successfully.");
        clickOnElement(shoppingCartProp.getValue("proceedToCheckOutButton"), true);
    }

    public void continueFromBillingAddress() {
        System.out.println(" Continue From Billing Address.");
        clickOnElement(shoppingCartProp.getValue("continueFromBillingAddress"), true);
    }

    public void continueFromShippingMethod() {
        System.out.println("Continue From Shipping Method.");
        clickOnElement(shoppingCartProp.getValue("continueFromShoppingMethod"), true);
    }

    public void selectPaymentMethod() {
        clickOnElement(shoppingCartProp.getValue("paymentMethod"), true);
    }

    public void continueFromPaymentMethod() {
        clickOnElement(shoppingCartProp.getValue("continueFromPaymentMethod"), true);
    }

    public void placeOrder() {
        clickOnElement(shoppingCartProp.getValue("placeOrder"), true);
    }

    public boolean isOrderSuccessfullyDone() {
        getElementText(shoppingCartProp.getValue("orderPlacedConfirmationMessage"), true).contains("YOUR ORDER HAS BEEN RECEIVED.");
        System.out.println("YOUR ORDER HAS BEEN RECEIVED.");
        return true;
    }

    public void orderId() {
        String text = getElementText(shoppingCartProp.getValue("orderId"), true);
        System.out.println("Your Order Id is :" + text);
    }

    public void enterCouponCode(String couponCode) {
        WebElement element = clickOnElement(shoppingCartProp.getValue("enterCoupon"), true);
        element.clear();
        element.sendKeys(couponCode);
        System.out.println("Coupon entered Succesfully.");
    }

    public void clickOnApply() {
        clickOnElement(shoppingCartProp.getValue("applyButton"), true);
        System.out.println("Apply Button Clicked.");
    }

    public void checkDiscountIsGenerated() {
        double element = Double.parseDouble(getElementText(shoppingCartProp.getValue("discountPrice"), true).replace("$", "").replace("-", ""));
        if ((getFlatRatePrice() * 5 / 100) == element) {
            System.out.println("Discount Price is Generated. The Price is :" + element);
        } else {
            System.out.println("The Discount is not Generated Correctly. The Price is :" + element);
        }

    }

}
