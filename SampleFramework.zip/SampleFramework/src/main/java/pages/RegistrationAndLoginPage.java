package pages;

import base.PredefinedActions;
import constants.ConstantPaths;
import utils.PropertyReading;

import java.util.HashMap;
import java.util.Map;

public class RegistrationAndLoginPage extends PredefinedActions {
    private static RegistrationAndLoginPage registrationAndLoginPage;
    private static PropertyReading registrationPageProp;
    private static PropertyReading registrationDetailProp;

    private RegistrationAndLoginPage() {
        registrationPageProp = new PropertyReading(ConstantPaths.LOCATOR_PATH + "RegistrationAndLoginPage.properties");
        registrationDetailProp = new PropertyReading(ConstantPaths.LOCATOR_PATH + "UserDetails.properties");
    }

    public static RegistrationAndLoginPage getRegistrationAndLoginPage() {
        if (registrationAndLoginPage == null) {
            registrationAndLoginPage = new RegistrationAndLoginPage();
        }
        return registrationAndLoginPage;
    }

    public void clickOnCreateMyAccountBtn() {
        clickOnElement(registrationPageProp.getValue("createMyAccountbtn"), true);
    }

    public Map<String, String> getRegistrationDetailList() {
        HashMap<String, String> tempMap = new HashMap<>();
        tempMap.put("firstName", registrationDetailProp.getValue("firstName"));
        tempMap.put("lastName", registrationDetailProp.getValue("lastName"));
        tempMap.put("email", registrationDetailProp.getValue("email"));
        tempMap.put("password", registrationDetailProp.getValue("password"));
        tempMap.put("confirmPass", registrationDetailProp.getValue("confirmPass"));
        return tempMap;
    }

    public void fillRegistrationDetails(String firstName, String lastName, String email, String password, String confirmPass) {
        clickThenEnterText(getElement(registrationPageProp.getValue("inputFirstName"), true), firstName);
        clickThenEnterText(getElement(registrationPageProp.getValue("inputLastName"), true), lastName);
        clickThenEnterText(getElement(registrationPageProp.getValue("inputEmailAddress"), true), email);
        clickThenEnterText(getElement(registrationPageProp.getValue("inputPassword"), true), password);
        clickThenEnterText(getElement(registrationPageProp.getValue("inputConfirmPassword"), true), confirmPass);
    }

    public void clickOnSubmitBtn() {
        clickOnElement(registrationPageProp.getValue("submitRegistration"), true);
    }

    public boolean isRegistrationSuccessful() {
        return getElementText(registrationPageProp.getValue("welcomeUser"), true).contains("Thank you for registering with Main Website Store.");
    }

    public Map<String, String> getLoginDetails() {
        HashMap<String, String> tempMap = new HashMap<>();
        tempMap.put("email", registrationDetailProp.getValue("loginEmail"));
        tempMap.put("password", registrationDetailProp.getValue("loginPass"));
        return tempMap;
    }

    public void fillLoginDetails(String email, String password) {
        clickThenEnterText(getElement(registrationPageProp.getValue("enterMail"), true), email);
        clickThenEnterText(getElement(registrationPageProp.getValue("enterPass"), true), password);
    }

    public void clickOnLoginButton() {
        clickOnElement(registrationPageProp.getValue("clickOnLogin"), true);
    }

    public void clickOnWishlistButton() {
        clickOnElement(registrationPageProp.getValue("clickOnWishlistButton"), true);
    }

    public void clickOnOrderPage() {
        clickOnElement(registrationPageProp.getValue("clickOnOrderPage"), true);
    }

    public void getOrderIdFromOrderPage() {
        String order = getElementText(registrationPageProp.getValue("orderId"), true);
        System.out.println("Order Number is showing on Order Page:" + order);
    }

    public void clickOnViewOrder() {
        clickOnElement(registrationPageProp.getValue("viewOrder"), true);
    }

    public String getOrderIdFromOrderDiscriptionPage() {
        String order = getElementText(registrationPageProp.getValue("orderIdUser"), true).replace("PENDING", "").replace("-", "").replace("#", "").trim().replace(" ", "").replace("ORDER", "");
        System.out.println("This is Your Order Id:" + order);
        return order;
    }
    public void reorder(){
     clickOnElement(registrationPageProp.getValue("reorderButton"),true);
    }

}
