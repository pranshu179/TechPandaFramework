package pages;

import base.PredefinedActions;
import constants.ConstantPaths;
import org.apache.log4j.Logger;
import org.openqa.selenium.WebElement;
import utils.PropertyReading;

public class Homepage extends PredefinedActions {

    private static Homepage homepage;
    private static PropertyReading homepageProp;
    private static Logger log = Logger.getLogger("HomePage");

    private Homepage() {
        homepageProp = new PropertyReading(ConstantPaths.LOCATOR_PATH + "Homepage.properties");
    }

    public static Homepage getHomepage() {
        if (homepage == null)
            homepage = new Homepage();
        log.trace("Object Created of HomePage Class.");
        return homepage;
    }

    public String getPageText() {
        return getElementText(homepageProp.getValue("headingText"), true);
    }

    public void goToProductPageMobile() {
        log.trace("User is going to Product Mobile Page.");
        clickOnElement(homepageProp.getValue("mobilePageMenuBtn"), true);
    }

    public void clickOnAccountBtn() {
        log.trace("User is click to Account button.");
        clickOnElement(homepageProp.getValue("accountBtn"), true);
    }

    public void clickOnMyAccountBtn() {
        log.trace("User is clicking My Account Button.");
        clickOnElement(homepageProp.getValue("myAccountBtn"), true);
    }
    public  void clickOnLogin(){
        log.trace("User click on Login button.");
        clickOnElement(homepageProp.getValue("loginButtonFromDropDown"),true); }
}
