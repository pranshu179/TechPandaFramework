package pages;

import base.PredefinedActions;
import constants.ConstantPaths;
import utils.PropertyReading;

import java.util.HashMap;
import java.util.Map;

public class WishlistPage extends PredefinedActions {
    private static WishlistPage wishlistpage;
    private static PropertyReading wishlistprop;

    private WishlistPage() {
        wishlistprop = new PropertyReading(ConstantPaths.LOCATOR_PATH + "Wishlist.properties");
    }

    public static WishlistPage getWishlistPage() {
        if (wishlistpage == null)
            wishlistpage = new WishlistPage();
        return wishlistpage;
    }

    public void clickOnShareWishList() {
        clickOnElement(wishlistprop.getValue("wishlistButton"), true);
    }

    public void enterMailInWishlist(String mail) {
        clickThenEnterText(getElement(wishlistprop.getValue("enterMail"), true), mail);
    }

    public void enterMessageInWishlist(String message) {
        clickThenEnterText(getElement(wishlistprop.getValue("enterMessage"), true), message);
    }

    public boolean isWishlistSuccessDone() {
        return getElementText(wishlistprop.getValue("verifyMessage"), true).contains("Your Wishlist has been shared.");
    }

    public void clickOnAddToCart() {
     clickOnElement(wishlistprop.getValue("clickOnAddToCartButton"),true);
    }





}
