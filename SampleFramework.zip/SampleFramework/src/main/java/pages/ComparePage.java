package pages;

import base.PredefinedActions;
import constants.ConstantPaths;
import utils.PropertyReading;

import java.util.logging.Logger;

public class ComparePage extends PredefinedActions {

    private static ComparePage comparePage;
    private static PropertyReading comparepagepro;

    private static Logger log = Logger.getLogger("ComparePage");
    private ComparePage (){
        comparepagepro = new PropertyReading(ConstantPaths.LOCATOR_PATH+"ComparePage.properties");
    }

    public static ComparePage  getComparePage() {
        if (comparePage == null) {
           comparePage= new ComparePage();
        }

        return comparePage;
    }


}
