package testscripts;

import jdk.jfr.Enabled;
import org.apache.commons.io.filefilter.FalseFileFilter;
import org.testng.Assert;
import org.testng.annotations.Test;
import pages.*;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Map;


public class VerifyProductTest extends TestBase {

    @Test(enabled = true)
    public void verifyHomePageAndProductsTest() {
        Homepage homepage = Homepage.getHomepage();
        Assert.assertEquals(homepage.getPageText(), "This is demo site for   ".toUpperCase());
        homepage.goToProductPageMobile();
        ProductPage productPage = ProductPage.getProductPage();
        Assert.assertTrue(productPage.isHeadingVisible());
        productPage.nameListBeforeSorting();
        System.out.println(productPage.nameListBeforeSorting());
        productPage.sortByName();
        System.out.println(productPage.sortedByNameList());
        Assert.assertEquals(productPage.sortedByNameList(), new ArrayList<>(Arrays.asList("IPHONE", "SAMSUNG GALAXY", "SONY XPERIA")));
    }

    @Test(enabled = false)
    public void verifyProductCost() {
        Homepage homepage = Homepage.getHomepage();
        homepage.goToProductPageMobile();

        ProductPage productPage = ProductPage.getProductPage();
        double priceInProductPage = productPage.getMobilePrice();
        productPage.goToProductDetailPage("Xperia");

        DetailPage detailPage = DetailPage.getDetailPage();
        detailPage.getDetailPagePrice();
        Assert.assertEquals(priceInProductPage, detailPage.getDetailPagePrice());
    }

    @Test(enabled = false)
    public void verifyCart() {
        Homepage homepage = Homepage.getHomepage();
        homepage.goToProductPageMobile();
        ProductPage productPage = ProductPage.getProductPage();
        productPage.addToCartProduct("Sony Xperia");

        ShoppingCartPage shopingCartPage = ShoppingCartPage.getShoppingCartPage();
        shopingCartPage.addProductToQty("1000");
        shopingCartPage.updateQtyButton();
        //Assert.assertEquals(shopingCartPage.getErrorMessage(), "Some of the products cannot be ordered in requested quantity.");
        Assert.assertTrue(shopingCartPage.isErrorMessageVisible());
        shopingCartPage.emptyCart();
        Assert.assertTrue(shopingCartPage.verifyEmptyCart());
    }

    @Test(enabled = false)
    public void verifyProductCompare() {
        Homepage homepage = Homepage.getHomepage();
        homepage.goToProductPageMobile();

        ProductPage productPage = ProductPage.getProductPage();
        ArrayList<String> productList = productPage.getProductNameText();
        productPage.clickOnAddToCompareBtn("Xperia");
        productPage.clickOnAddToCompareBtn("IPhone");
        productPage.clickOnProductCompare();
        Assert.assertTrue(productPage.isComparePageVisible());
        ArrayList<String> comparePageProductName = productPage.getComparePageProductName();
        Assert.assertEquals(productList.get(0), comparePageProductName.get(0));
        Assert.assertEquals(productList.get(1), comparePageProductName.get(1));
        productPage.afterAction();
    }

    @Test(enabled = false)
    public void verifyAccountRegistration() {
        Homepage homepage = Homepage.getHomepage();
        homepage.clickOnAccountBtn();
        homepage.clickOnMyAccountBtn();
        RegistrationAndLoginPage registrationAndLoginPage = RegistrationAndLoginPage.getRegistrationAndLoginPage();
        registrationAndLoginPage.clickOnCreateMyAccountBtn();
        Map<String, String> detailMap = registrationAndLoginPage.getRegistrationDetailList();
        registrationAndLoginPage.fillRegistrationDetails(detailMap.get("firstName"),
                detailMap.get("lastName"),
                detailMap.get("email"),
                detailMap.get("password"),
                detailMap.get("confirmPass"));
        registrationAndLoginPage.clickOnSubmitBtn();
        registrationAndLoginPage.isRegistrationSuccessful();
        Assert.assertTrue(registrationAndLoginPage.isRegistrationSuccessful());

        TvPage tvpage = TvPage.getTvPage();
        tvpage.goToTvPage();
        tvpage.addProductToWishlist("LG LCD");
        /** Map<String,String> detailsMap = registrationAndLoginPage.getLoginDetails();
         registrationAndLoginPage.fillLoginDetails(detailsMap.get("loginEmail"), detailsMap.get("loginPass"));
         registrationAndLoginPage.clickOnLoginButton();*/
        WishlistPage wishlistpage = WishlistPage.getWishlistPage();
        wishlistpage.clickOnShareWishList();
        wishlistpage.enterMailInWishlist("Pranshubajpaibjp@gmail.com");
        wishlistpage.enterMessageInWishlist("This Is For You");
        wishlistpage.clickOnShareWishList();
        Assert.assertTrue(wishlistpage.isWishlistSuccessDone());
    }

    @Test(enabled = false)
    public void VerifyProceedToCheckOutPage() {

        Homepage homepage = Homepage.getHomepage();

        RegistrationAndLoginPage registrationAndLoginPage = RegistrationAndLoginPage.getRegistrationAndLoginPage();

        WishlistPage wishlistPage = WishlistPage.getWishlistPage();

        TvPage tvpage = TvPage.getTvPage();
        homepage.clickOnAccountBtn();
        homepage.clickOnLogin();
        Map<String, String> detailsMap = registrationAndLoginPage.getLoginDetails();
        registrationAndLoginPage.fillLoginDetails(detailsMap.get("email"), detailsMap.get("password"));
        registrationAndLoginPage.clickOnLoginButton();
        tvpage.goToTvPage();
        tvpage.addProductToWishlist("LG LCD");
        registrationAndLoginPage.clickOnWishlistButton();
        wishlistPage.clickOnAddToCart();

        ShoppingCartPage shoppingCartPage = ShoppingCartPage.getShoppingCartPage();
//        shopingCartPage.proceedToCheckout();
//        shopingCartPage.fillShoppingForm("ABC","New York","New York","542896","United States","12345678");
        shoppingCartPage.selectCountryStateAndZip("United States", "New York", "542896");
        shoppingCartPage.clickOnEstimateButton();
//        shoppingCartPage.getShoppingPrice();
        shoppingCartPage.clickOnFixedRate();
        shoppingCartPage.getFlatRatePrice();
        shoppingCartPage.getSubTotalPrice();
        shoppingCartPage.getGrandTotalPrice();
        shoppingCartPage.isTotalPriceCorrect();
        shoppingCartPage.clickOnProceedToCheckOut();
        shoppingCartPage.continueFromBillingAddress();
        shoppingCartPage.continueFromShippingMethod();
        shoppingCartPage.selectPaymentMethod();
        shoppingCartPage.continueFromPaymentMethod();
        shoppingCartPage.placeOrder();
        shoppingCartPage.isOrderSuccessfullyDone();
        shoppingCartPage.orderId();
    }

    @Test(enabled = false)
    public void verifyOrderDetails() {
        Homepage homepage = Homepage.getHomepage();
        RegistrationAndLoginPage registrationAndLoginPage = RegistrationAndLoginPage.getRegistrationAndLoginPage();
        ShoppingCartPage shoppingCartPage = ShoppingCartPage.getShoppingCartPage();
        homepage.clickOnAccountBtn();
        homepage.clickOnLogin();
        Map<String, String> details = registrationAndLoginPage.getLoginDetails();
        registrationAndLoginPage.fillLoginDetails(details.get("email"), details.get("password"));
        registrationAndLoginPage.clickOnLoginButton();
        registrationAndLoginPage.clickOnOrderPage();
        registrationAndLoginPage.getOrderIdFromOrderPage();
        registrationAndLoginPage.clickOnViewOrder();
        registrationAndLoginPage.getOrderIdFromOrderDiscriptionPage();
    }

    @Test
    public void verifyReorder() {

        Homepage homepage = Homepage.getHomepage();
        RegistrationAndLoginPage registrationAndLoginPage = RegistrationAndLoginPage.getRegistrationAndLoginPage();
        ShoppingCartPage shoppingCartPage = ShoppingCartPage.getShoppingCartPage();
        homepage.clickOnAccountBtn();
        homepage.clickOnLogin();
        Map<String, String> login = registrationAndLoginPage.getLoginDetails();
        registrationAndLoginPage.fillLoginDetails(login.get("email"), login.get("password"));
        registrationAndLoginPage.clickOnLoginButton();
        registrationAndLoginPage.reorder();
        shoppingCartPage.addProductToQty("15");
        shoppingCartPage.updateQtyButton();
        shoppingCartPage.selectCountryStateAndZip("United States", "New York", "542896");
        shoppingCartPage.clickOnEstimateButton();
        shoppingCartPage.clickOnFixedRate();
        shoppingCartPage.getSubTotalPrice();
        shoppingCartPage.getFlatRatePrice();
        shoppingCartPage.getGrandTotalPrice();
        shoppingCartPage.isTotalPriceCorrect();
        shoppingCartPage.clickOnProceedToCheckOut();
        shoppingCartPage.continueFromBillingAddress();
        shoppingCartPage.continueFromShippingMethod();
        shoppingCartPage.selectPaymentMethod();
        shoppingCartPage.continueFromPaymentMethod();
        shoppingCartPage.placeOrder();
        shoppingCartPage.isOrderSuccessfullyDone();
        shoppingCartPage.orderId();
    }

    @Test(enabled = false)
    public void verifyDiscountCode() {
        Homepage homepage = Homepage.getHomepage();
        RegistrationAndLoginPage registrationAndLoginPage = RegistrationAndLoginPage.getRegistrationAndLoginPage();
        ShoppingCartPage shoppingCartPage = ShoppingCartPage.getShoppingCartPage();
        ProductPage productPage = ProductPage.getProductPage();
        homepage.clickOnAccountBtn();
        homepage.clickOnLogin();
        Map<String, String> login = registrationAndLoginPage.getLoginDetails();
        registrationAndLoginPage.fillLoginDetails(login.get("email"), login.get("password"));
        registrationAndLoginPage.clickOnLoginButton();
        homepage.goToProductPageMobile();
        productPage.addToCartProduct("IPhone");
        shoppingCartPage.addProductToQty("15");
        shoppingCartPage.updateQtyButton();
        shoppingCartPage.selectCountryStateAndZip("United States", "New York", "542896");
        shoppingCartPage.clickOnEstimateButton();
        shoppingCartPage.enterCouponCode("GURU50");
        shoppingCartPage.clickOnApply();
        shoppingCartPage.clickOnFixedRate();
        shoppingCartPage.getSubTotalPrice();
        shoppingCartPage.getFlatRatePrice();
        shoppingCartPage.checkDiscountIsGenerated();
    }


}
