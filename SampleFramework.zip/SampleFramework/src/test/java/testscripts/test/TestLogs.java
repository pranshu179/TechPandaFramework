package testscripts.test;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.openqa.selenium.logging.Logs;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import java.text.SimpleDateFormat;
import java.util.Date;

public class TestLogs {

  static Logger log = Logger.getLogger("TestLogs.class");


    @BeforeTest
    public void beforeTest(){
        SimpleDateFormat sdf = new SimpleDateFormat("dd_MM_yyyy_HH_mm");
        System.setProperty("current.date.time", sdf.format(new Date()));

        PropertyConfigurator.configure("C:\\Users\\Prans\\IdeaProjects\\SampleFramework\\src\\main\\resources\\ConfigFiles\\Log4j.properties");
    }

    @Test
    public void test(){

        //log.off
        log.trace("We are in trace");
        log.debug("We are in debug");
        log.info("We are in info");
        log.warn("We are in warn");
        log.error("We are in error");
        log.fatal("We are in fatal");

    }
}
