package testscripts.test;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

import java.util.Iterator;
import java.util.Set;

public class SeleniumWindow {

    @Test
    void m1() throws InterruptedException {
        WebDriver driver = new ChromeDriver();
        driver.get("https://demoqa.com/browser-windows");
        driver.manage().window().maximize();
        driver.findElement(By.cssSelector("#windowButton")).click();
        Set<String> setWindow = driver.getWindowHandles();
        Iterator<String> itr = setWindow.iterator();
        String parent = itr.next();
        String child = itr.next();

        driver.switchTo().window(child);
        System.out.println(driver.findElement(By.xpath("//h1")).getText());
        driver.close();

        driver.switchTo().window(parent);



    }
}
