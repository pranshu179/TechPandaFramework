package testscripts.test;

public class Main {
    public static void main(String[] args) {

        int a = 12;
        String s = String.valueOf(a);
        System.out.println(s);
    }
}
