package testscripts.test;

public class Example {

     static Example example;
    private Example(){

    }
    public static Example getExample (){
        if(example == null)
            example = new Example();
        return example;
    }
}
