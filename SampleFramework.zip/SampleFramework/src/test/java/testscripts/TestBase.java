package testscripts;

import base.PredefinedActions;
import constants.ConstantPaths;

import org.apache.log4j.PropertyConfigurator;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import utils.PropertyReading;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Objects;

public class TestBase {

    @BeforeClass
    public void beforeClassExecution(){
        SimpleDateFormat sdf = new SimpleDateFormat("dd_MM_yyyy_HH_mm");
        System.setProperty("current.date.time", sdf.format(new Date()));
        PropertyConfigurator.configure("C:\\Users\\Prans\\IdeaProjects\\SampleFramework\\src\\main\\resources\\ConfigFiles\\Log4j.properties");

    }

    @BeforeMethod()
    public void openBrowser(){
        PropertyReading configProp = new PropertyReading(ConstantPaths.CONFIG_PATH);
        ArrayList<String> configList = new ArrayList<>();
        configList.add(configProp.getValue("url"));
        configList.add(configProp.getValue("browser"));
        configList.add(configProp.getValue("isHeadless"));
        PredefinedActions.initializeBrowser(configList.get(0),configList.get(1), Boolean.parseBoolean(configList.get(2)));
    }
}
